'use strict';
const path = require('path');

console.log('[electron] [code_compress] ERROR dir is empty!!!');
return;