import AppSider from '@/layouts/AppSider'
import DemoMenu from '@/layouts/DemoMenu'

export {
    AppSider, 
    DemoMenu
}
